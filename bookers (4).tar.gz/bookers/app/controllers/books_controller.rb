class BooksController < ApplicationController
  def index
    @books = Book.all
    @book = Book.new
  end


  def create
      @books = Book.all
      @book = Book.new(list_params)
      if @book.save
      flash[:notice] = "Book was successfully destroyed."
      redirect_to book_path(@book.id)
      else
        @books = Book.all
        render 'index'
      end

  end

  def top
  end


  def show
    @book = Book.find(params[:id] )

  end
  def edit
    @book = Book.find(params[:id] )
    @books = Book.all
  end


  def update
    @books = Book.all
    @book = Book.find(params[:id])
    if @book.update(list_params)
    redirect_to book_path(@book.id)
    else
      render 'edit'
    end
  end

  def destroy
    @book = Book.find(params[:id] )
    book.destroy
    redirect_to book_path(@book.id)
  end

  private

  def book_params
    params.require(:book).permit(:title, :body)
  end
end
