class HomesController < ApplicationController
  def show
  end

  def new
    
  end

  def edit
  end

  def top

  end

  def create
  
  end

  def index
    
  end

  

  
  
end
